NextClassChip v1.4 stable-battery

핵심 변경점
1) 지연된 RTC 알람이 실행될 때 과거 명령을 그대로 실행하지 않고 현재 시간표를 다시 계산합니다.
2) Live Update 알림에 시스템 timeout을 추가해 hide 알람이 늦어져도 오래된 알림이 자동 제거됩니다.
3) TIME_SET / TIMEZONE_CHANGED 수신 시 예약을 재동기화합니다.
4) v1.3에서 실제 동작 확인된 Promoted Ongoing + ProgressStyle 구조를 유지합니다.
5) Notification.setColor() 강조색을 앱에서 순환 선택할 수 있습니다. 단, Samsung One UI의 Now Bar/Status Chip 배경색 자체는 시스템 UI가 결정하므로 색상 힌트를 무시할 수 있습니다.
6) setColorized(true)는 Live Update 승격 자격을 잃을 수 있으므로 절대 사용하지 않습니다.

배터리 설계
- 상시 Foreground Service 없음
- 반복 폴링 없음
- 네트워크/위치/센서/WakeLock 없음
- 다음 이벤트 1개만 AlarmManager.RTC로 예약(기기를 깨우지 않음)
- 이벤트 발생 시 잠깐 실행 후 다음 이벤트 1개만 다시 예약
