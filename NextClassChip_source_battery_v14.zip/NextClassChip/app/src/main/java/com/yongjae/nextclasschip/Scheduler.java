package com.yongjae.nextclasschip;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;

public final class Scheduler {
    private Scheduler() {}

    public static final String PREFS = "next_class_prefs";
    public static final String PREF_ENABLED = "enabled";
    public static final String ACTION_EVENT = "com.yongjae.nextclasschip.NEXT_EVENT";

    private static final int REQUEST_NEXT_EVENT = 4101;
    private static final ZoneId SCHOOL_ZONE = ZoneId.of("Asia/Seoul");

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(PREF_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(PREF_ENABLED, enabled).apply();
    }

    /**
     * 배터리 절약형 동기화.
     * 여러 주간 알람을 한꺼번에 등록하지 않고, 오직 '다음 이벤트 1개'만 예약한다.
     * 이벤트가 실행되면 AlarmReceiver가 다음 이벤트 1개를 이어서 예약한다.
     */
    public static void syncAndScheduleNext(Context context) {
        if (!isEnabled(context)) return;

        ZonedDateTime now = ZonedDateTime.now(SCHOOL_ZONE);
        CurrentWindow current = currentWindow(now);
        if (current != null) {
            long timeoutMs = Math.max(1_000L, java.time.Duration.between(now, current.hideEvent.when).toMillis());
            NotificationHelper.showNextClass(context, current.subject, timeoutMs);
            schedule(context, current.hideEvent);
            return;
        }

        NotificationHelper.cancel(context);
        Event next = findNextEvent(now.plusSeconds(1));
        if (next != null) schedule(context, next);
    }

    public static void scheduleNext(Context context) {
        if (!isEnabled(context)) return;
        Event next = findNextEvent(ZonedDateTime.now(SCHOOL_ZONE).plusSeconds(1));
        if (next != null) schedule(context, next);
    }

    private static void schedule(Context context, Event event) {
        AlarmManager am = context.getSystemService(AlarmManager.class);
        PendingIntent pi = pendingIntent(context, event, PendingIntent.FLAG_UPDATE_CURRENT);
        long at = event.when.toInstant().toEpochMilli();

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am.canScheduleExactAlarms()) {
                // RTC는 화면이 꺼져 있을 때 기기를 깨우지 않는다.
                // 사용자가 상태표시줄을 볼 수 없는 동안 불필요한 wake-up을 피하는 것이 목적이다.
                am.setExact(AlarmManager.RTC, at, pi);
            } else {
                // 정확한 알람 권한이 없으면 시스템이 배터리를 최적화할 수 있는 일반 알람 사용.
                am.set(AlarmManager.RTC, at, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC, at, pi);
        }
    }

    public static void cancelAll(Context context) {
        AlarmManager am = context.getSystemService(AlarmManager.class);
        PendingIntent pi = pendingIntentForCancel(context);
        if (pi != null) am.cancel(pi);
        NotificationHelper.cancel(context);
    }

    private static PendingIntent pendingIntent(Context context, Event event, int creationFlag) {
        Intent intent = new Intent(context, AlarmReceiver.class)
                .setAction(ACTION_EVENT);

        return PendingIntent.getBroadcast(
                context,
                REQUEST_NEXT_EVENT,
                intent,
                creationFlag | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static PendingIntent pendingIntentForCancel(Context context) {
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_EVENT);
        return PendingIntent.getBroadcast(
                context,
                REQUEST_NEXT_EVENT,
                intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static Event findNextEvent(ZonedDateTime after) {
        Event best = null;

        // 최대 8일만 보면 다음 평일 이벤트를 반드시 찾을 수 있다.
        for (int d = 0; d <= 8; d++) {
            LocalDate date = after.toLocalDate().plusDays(d);
            DayOfWeek day = date.getDayOfWeek();
            List<String> classes = ScheduleData.classesFor(day);
            if (classes.size() < 2) continue;

            for (int transition = 0; transition < classes.size() - 1; transition++) {
                String subject = classes.get(transition + 1);
                ZonedDateTime show = ZonedDateTime.of(
                        date,
                        ScheduleData.END_TIMES[transition].minusMinutes(5),
                        SCHOOL_ZONE
                );
                ZonedDateTime hide = ZonedDateTime.of(
                        date,
                        ScheduleData.START_TIMES[transition + 1],
                        SCHOOL_ZONE
                );

                if (show.isAfter(after)) {
                    Event e = new Event(show, true, subject);
                    if (best == null || e.when.isBefore(best.when)) best = e;
                }
                if (hide.isAfter(after)) {
                    Event e = new Event(hide, false, subject);
                    if (best == null || e.when.isBefore(best.when)) best = e;
                }
            }
        }
        return best;
    }

    private static CurrentWindow currentWindow(ZonedDateTime now) {
        List<String> classes = ScheduleData.classesFor(now.getDayOfWeek());
        if (classes.size() < 2) return null;

        LocalDate date = now.toLocalDate();
        for (int transition = 0; transition < classes.size() - 1; transition++) {
            ZonedDateTime show = ZonedDateTime.of(
                    date,
                    ScheduleData.END_TIMES[transition].minusMinutes(5),
                    SCHOOL_ZONE
            );
            ZonedDateTime hide = ZonedDateTime.of(
                    date,
                    ScheduleData.START_TIMES[transition + 1],
                    SCHOOL_ZONE
            );
            if (!now.isBefore(show) && now.isBefore(hide)) {
                String subject = classes.get(transition + 1);
                return new CurrentWindow(subject, new Event(hide, false, subject));
            }
        }
        return null;
    }

    public static String nextWindowSummary() {
        ZonedDateTime now = ZonedDateTime.now(SCHOOL_ZONE);
        List<String> classes = ScheduleData.classesFor(now.getDayOfWeek());

        if (classes.size() >= 2) {
            for (int transition = 0; transition < classes.size() - 1; transition++) {
                LocalTime showTime = ScheduleData.END_TIMES[transition].minusMinutes(5);
                LocalTime hideTime = ScheduleData.START_TIMES[transition + 1];
                ZonedDateTime show = ZonedDateTime.of(now.toLocalDate(), showTime, SCHOOL_ZONE);
                ZonedDateTime hide = ZonedDateTime.of(now.toLocalDate(), hideTime, SCHOOL_ZONE);
                if (now.isBefore(hide)) {
                    String subject = classes.get(transition + 1);
                    if (!now.isBefore(show)) {
                        return "지금 표시 구간 · 다음교시: " + subject + " · " + hideTime + "까지";
                    }
                    long mins = Math.max(0, Duration.between(now, show).toMinutes());
                    return "다음 표시 · " + showTime + " · 다음교시: " + subject + " (약 " + mins + "분 후)";
                }
            }
        }

        Event next = findNextEvent(now.plusSeconds(1));
        if (next != null && next.show) {
            return "다음 표시 · " + ScheduleData.dayName(next.when.getDayOfWeek()) + " "
                    + next.when.toLocalTime() + " · 다음교시: " + next.subject;
        }
        return "오늘 알림은 모두 끝났습니다.";
    }

    private static final class Event {
        final ZonedDateTime when;
        final boolean show;
        final String subject;

        Event(ZonedDateTime when, boolean show, String subject) {
            this.when = when;
            this.show = show;
            this.subject = subject;
        }
    }

    private static final class CurrentWindow {
        final String subject;
        final Event hideEvent;

        CurrentWindow(String subject, Event hideEvent) {
            this.subject = subject;
            this.hideEvent = hideEvent;
        }
    }
}
