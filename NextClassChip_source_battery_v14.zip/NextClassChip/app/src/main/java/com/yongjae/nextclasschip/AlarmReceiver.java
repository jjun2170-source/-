package com.yongjae.nextclasschip;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Scheduler.isEnabled(context)) return;

        /*
         * v1.4 핵심 안정화:
         * AlarmManager.RTC는 기기를 깨우지 않으므로 예약 시각보다 늦게 전달될 수 있다.
         * 따라서 Intent에 저장된 과거의 show/hide 명령을 실행하지 않고,
         * '지금 이 순간'의 날짜/시간을 다시 계산해 올바른 상태를 동기화한다.
         */
        Scheduler.syncAndScheduleNext(context);
    }
}
