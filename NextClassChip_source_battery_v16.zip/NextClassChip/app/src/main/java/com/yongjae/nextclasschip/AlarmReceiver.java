package com.yongjae.nextclasschip;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Scheduler.isEnabled(context)) return;

        // 실제 AlarmManager 예약이 언제 전달됐는지 앱 화면에서 확인할 수 있게 기록한다.
        Scheduler.recordAlarmFired(context);

        /*
         * Intent에 과거 show/hide 상태를 저장하지 않는다.
         * 수신 순간의 서울 시각과 시간표를 다시 계산하므로 지연 수신 시에도
         * 이미 끝난 '다음교시'가 뒤늦게 나타나는 오류를 방지한다.
         */
        Scheduler.syncAndScheduleNext(context);
    }
}
