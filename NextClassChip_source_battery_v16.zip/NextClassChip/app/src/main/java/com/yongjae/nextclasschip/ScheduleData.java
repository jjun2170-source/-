package com.yongjae.nextclasschip;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ScheduleData {
    private ScheduleData() {}

    /*
     * 실제 교시 시작 시각.
     * 1교시 09:00, 2교시 10:00, 3교시 11:00, 4교시 12:00,
     * 5교시 14:00, 6교시 15:00, 7교시 16:00.
     */
    public static final LocalTime[] START_TIMES = {
            LocalTime.of(9, 0),
            LocalTime.of(10, 0),
            LocalTime.of(11, 0),
            LocalTime.of(12, 0),
            LocalTime.of(14, 0),
            LocalTime.of(15, 0),
            LocalTime.of(16, 0)
    };

    /* 실제 교시 종료 시각. */
    public static final LocalTime[] END_TIMES = {
            LocalTime.of(9, 50),
            LocalTime.of(10, 50),
            LocalTime.of(11, 50),
            LocalTime.of(12, 50),
            LocalTime.of(14, 50),
            LocalTime.of(15, 50),
            LocalTime.of(16, 50)
    };

    /*
     * V1.6에서 가장 중요한 값: '그 교시에 들을 과목'을 Now Bar에 띄우기 시작하는 시각.
     * 사용 목적은 현재 수업이 끝나기 전에 다음 이동 수업의 교과서를 준비하는 것.
     * 1교시는 등교 직후 준비를 위해 08:45, 2~4교시는 직전 수업 종료 5분 전,
     * 5교시는 점심 전 4교시 종료 5분 전인 12:45부터, 6~7교시는 각각 14:45/15:45.
     */
    public static final LocalTime[] DISPLAY_START_TIMES = {
            LocalTime.of(8, 45),
            LocalTime.of(9, 45),
            LocalTime.of(10, 45),
            LocalTime.of(11, 45),
            LocalTime.of(12, 45),
            LocalTime.of(14, 45),
            LocalTime.of(15, 45)
    };

    private static final EnumMap<DayOfWeek, List<String>> TIMETABLE = new EnumMap<>(DayOfWeek.class);

    static {
        TIMETABLE.put(DayOfWeek.MONDAY,
                List.of("지2", "물2", "영독작", "화작", "체육", "심리학"));
        TIMETABLE.put(DayOfWeek.TUESDAY,
                List.of("물2", "영독작", "화2", "지2", "화작", "심리학"));
        TIMETABLE.put(DayOfWeek.WEDNESDAY,
                List.of("수과탐", "사문탐", "미적분", "지2"));
        TIMETABLE.put(DayOfWeek.THURSDAY,
                List.of("화2", "심리학", "물2", "사문탐", "수과탐", "미적분", "체육"));
        TIMETABLE.put(DayOfWeek.FRIDAY,
                List.of("미적분", "사문탐", "화2", "영독작", "체육", "수과탐", "화작"));
    }

    public static List<String> classesFor(DayOfWeek day) {
        return TIMETABLE.getOrDefault(day, Collections.emptyList());
    }

    public static Map<DayOfWeek, List<String>> timetable() {
        return Collections.unmodifiableMap(TIMETABLE);
    }

    public static String dayName(DayOfWeek day) {
        return switch (day) {
            case MONDAY -> "월";
            case TUESDAY -> "화";
            case WEDNESDAY -> "수";
            case THURSDAY -> "목";
            case FRIDAY -> "금";
            case SATURDAY -> "토";
            case SUNDAY -> "일";
        };
    }
}
