package com.yongjae.nextclasschip;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class SystemTimeReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Scheduler.isEnabled(context)) {
            // 사용자가 시스템 시간을 바꾸거나 시간대가 바뀐 경우 예약을 즉시 재동기화한다.
            Scheduler.syncAndScheduleNext(context);
        }
    }
}
