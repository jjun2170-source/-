package com.yongjae.nextclasschip;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.service.notification.StatusBarNotification;

public final class NotificationHelper {
    private NotificationHelper() {}

    // v1.6은 교시 매핑 수정판 전용 새 채널을 사용한다.
    public static final String CHANNEL_ID = "next_class_live_v16";
    public static final int NOTIFICATION_ID = 1001;
    public static final int TEST_NOTIFICATION_ID = 1002;

    private static final String COLOR_PREFS = "next_class_color";
    private static final String PREF_COLOR_INDEX = "accent_index";

    // 0은 시스템 기본색. 나머지는 Notification.setColor()로 전달되는 강조색이다.
    private static final int[] ACCENT_COLORS = {
            0,
            Color.rgb(124, 77, 255),   // 보라
            Color.rgb(0, 150, 136),    // 청록
            Color.rgb(46, 125, 50),    // 초록
            Color.rgb(245, 124, 0),    // 주황
            Color.rgb(198, 40, 40)     // 빨강
    };

    private static final String[] ACCENT_NAMES = {
            "시스템 기본", "보라", "청록", "초록", "주황", "빨강"
    };

    public static void ensureChannel(Context context) {
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "다음 교시 · 실시간",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        channel.setDescription("다음 수업이 가까워졌을 때 Live Update/Status Chip으로 표시합니다.");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setShowBadge(false);
        nm.createNotificationChannel(channel);
    }

    public static void showNextClass(Context context, String subject, long timeoutMs) {
        show(context, subject, NOTIFICATION_ID, timeoutMs);
    }

    public static void showTest(Context context, String subject) {
        show(context, subject, TEST_NOTIFICATION_ID, 30_000L);
    }

    private static void show(Context context, String subject, int id, long timeoutMs) {
        if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        ensureChannel(context);

        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                0,
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_school)
                .setContentTitle("다음교시: " + subject)
                .setContentText("다음 수업이 곧 시작합니다.")
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_STATUS)
                .setShowWhen(false)
                // setColorized(true)는 Live Update 승격 자격을 잃게 하므로 사용하지 않는다.
                .setColorized(false)
                .setShortCriticalText(chipText(subject));

        int accent = getAccentColor(context);
        if (accent != 0) {
            // 시스템이 허용하는 '강조색' 힌트. One UI가 Now Bar 배경 자체에는 적용하지 않을 수 있다.
            builder.setColor(accent);
        }

        // 알람 전달이 지연되더라도 시스템이 오래된 Now Bar를 스스로 제거하는 안전장치.
        if (timeoutMs > 0) {
            builder.setTimeoutAfter(Math.max(1_000L, timeoutMs));
        }

        // v1.3에서 Galaxy Tab S9 Ultra / One UI 8.5에서 실제 승격이 확인된 형태를 유지한다.
        if (Build.VERSION.SDK_INT >= 36) {
            builder.setStyle(new Notification.ProgressStyle()
                    .setProgressIndeterminate(true));
        }

        if (Build.VERSION.SDK_INT_FULL >= Build.VERSION_CODES_FULL.BAKLAVA_1) {
            builder.setRequestPromotedOngoing(true);
        }

        Notification notification = builder.build();
        context.getSystemService(NotificationManager.class).notify(id, notification);
    }

    public static String chipText(String subject) {
        String full = "다음교시:" + subject;
        int count = full.codePointCount(0, full.length());
        return count <= 7 ? full : subject;
    }

    public static String promotionDiagnostics(Context context, int id) {
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        boolean canPost = Build.VERSION.SDK_INT >= 36 && nm.canPostPromotedNotifications();
        StatusBarNotification target = null;
        for (StatusBarNotification sbn : nm.getActiveNotifications()) {
            if (sbn.getId() == id) {
                target = sbn;
                break;
            }
        }
        if (target == null) {
            return "진단: 게시된 테스트 알림을 찾지 못함";
        }

        Notification n = target.getNotification();
        boolean promotable = Build.VERSION.SDK_INT >= 36 && n.hasPromotableCharacteristics();
        boolean promoted = Build.VERSION.SDK_INT >= 36 &&
                (n.flags & Notification.FLAG_PROMOTED_ONGOING) != 0;
        boolean requested = Build.VERSION.SDK_INT_FULL >= Build.VERSION_CODES_FULL.BAKLAVA_1
                && n.isRequestPromotedOngoing();
        NotificationChannel channel = nm.getNotificationChannel(CHANNEL_ID);
        int importance = channel == null ? -1 : channel.getImportance();

        return "Live Update 진단\n" +
                "• 승격 요청: " + ox(requested) + "\n" +
                "• Android 자격 충족: " + ox(promotable) + "\n" +
                "• 앱 승격 허용: " + ox(canPost) + "\n" +
                "• 시스템 실제 승격: " + ox(promoted) + "\n" +
                "• 채널 중요도: " + importance + " (DEFAULT=3)";
    }

    public static String accentName(Context context) {
        return ACCENT_NAMES[getAccentIndex(context)];
    }

    public static void cycleAccentColor(Context context) {
        int next = (getAccentIndex(context) + 1) % ACCENT_COLORS.length;
        context.getSharedPreferences(COLOR_PREFS, Context.MODE_PRIVATE)
                .edit().putInt(PREF_COLOR_INDEX, next).apply();
    }

    private static int getAccentColor(Context context) {
        return ACCENT_COLORS[getAccentIndex(context)];
    }

    private static int getAccentIndex(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(COLOR_PREFS, Context.MODE_PRIVATE);
        int index = prefs.getInt(PREF_COLOR_INDEX, 1); // 기본값은 보라
        if (index < 0 || index >= ACCENT_COLORS.length) return 1;
        return index;
    }

    private static String ox(boolean value) {
        return value ? "O" : "X";
    }

    public static void cancel(Context context) {
        context.getSystemService(NotificationManager.class).cancel(NOTIFICATION_ID);
    }

    public static void cancelTest(Context context) {
        context.getSystemService(NotificationManager.class).cancel(TEST_NOTIFICATION_ID);
    }
}
