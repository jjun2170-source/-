from datetime import time

schedule = {
    '월': ['지2','물2','영독작','화작','체육','심리학'],
    '화': ['물2','영독작','화2','지2','화작','심리학'],
    '수': ['수과탐','사문탐','미적분','지2'],
    '목': ['화2','심리학','물2','사문탐','수과탐','미적분','체육'],
    '금': ['미적분','사문탐','화2','영독작','체육','수과탐','화작'],
}
starts = [time(9), time(10), time(11), time(12), time(14), time(15), time(16)]
shows  = [time(8,45), time(9,45), time(10,45), time(11,45), time(12,45), time(14,45), time(15,45)]

for day, classes in schedule.items():
    print(day, ' → '.join(classes))
    for i, subject in enumerate(classes):
        print(f'  {shows[i].strftime("%H:%M")}-{starts[i].strftime("%H:%M")}  다음교시:{subject}')
