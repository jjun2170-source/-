NextClassChip v1.5 - exact transition window

핵심 로직
- 현재 수업 종료 5분 전부터 다음 수업 시작 직전까지 다음교시를 표시한다.
- 일반 교시 전환: xx:45 ~ 다음 정각 (15분 유지, 내용 업데이트 없음)
- 점심 전환(5→6교시): 12:45 ~ 14:00
- 다음 수업 시작 시 즉시 제거한다.
- 그날 마지막 수업 뒤에는 표시하지 않는다.

신뢰성 변경
- AlarmManager.RTC -> RTC_WAKEUP
- setExact -> setExactAndAllowWhileIdle
- 정확한 알람 권한이 없으면 시간표 알림 켜기를 막고 설정 화면으로 안내
- 수신 시 현재 시각을 재계산하여 늦게 도착한 과거 상태를 표시하지 않음
- 다음 예약/마지막 실행 시각을 앱 화면에 표시하여 진단 가능
- Notification timeout을 hide 시각까지 보조 안전장치로 유지

배터리
- 상시 서비스, polling, 위치, 네트워크, wakelock 없음
- 다음 show/hide 이벤트 1개만 예약
- 화면이 꺼져 있어도 정확한 시각이 중요하므로 전환 시점에만 기기를 깨움

검증 기능
- ‘실제 예약 20초 테스트’: 일반 버튼처럼 즉시 notify하지 않고 RTC_WAKEUP exact alarm을 실제로 예약함.
- 버튼을 누른 뒤 최근 앱에서 닫거나 화면을 꺼도 20초 후 수과탐 Now Bar가 뜨면 실시간 예약 경로가 정상임.
