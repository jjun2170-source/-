package com.yongjae.nextclasschip;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public final class Scheduler {
    private Scheduler() {}

    public static final String PREFS = "next_class_prefs";
    public static final String PREF_ENABLED = "enabled";
    public static final String ACTION_EVENT = "com.yongjae.nextclasschip.NEXT_EVENT";

    private static final String PREF_LAST_FIRED = "last_fired";
    private static final String PREF_NEXT_EVENT = "next_event";
    private static final int REQUEST_NEXT_EVENT = 4101;
    private static final ZoneId SCHOOL_ZONE = ZoneId.of("Asia/Seoul");
    private static final DateTimeFormatter DEBUG_TIME = DateTimeFormatter.ofPattern("M/d(E) HH:mm:ss");

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(PREF_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(PREF_ENABLED, enabled).apply();
    }

    public static boolean canSchedulePrecisely(Context context) {
        AlarmManager am = context.getSystemService(AlarmManager.class);
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms();
    }

    /**
     * v1.5의 핵심 규칙:
     * 1) 현재 수업 종료 5분 전(show)부터 다음 수업 시작(hide) 직전까지만 다음 과목 표시.
     * 2) 표시된 15분(점심 전환은 12:45~14:00) 동안 내용 갱신 없음.
     * 3) show/hide 자체는 RTC_WAKEUP + setExactAndAllowWhileIdle로 예약하여
     *    최근 앱을 닫았거나 화면이 꺼져 있어도 정해진 시각에 실행되도록 한다.
     * 4) 알람이 어떤 이유로 늦게 도착하면 과거 명령을 믿지 않고 현재 시각을 다시 계산한다.
     */
    public static void syncAndScheduleNext(Context context) {
        if (!isEnabled(context)) return;

        ZonedDateTime now = ZonedDateTime.now(SCHOOL_ZONE);
        CurrentWindow current = currentWindow(now);
        if (current != null) {
            long timeoutMs = Math.max(1_000L, Duration.between(now, current.hideEvent.when).toMillis());
            NotificationHelper.showNextClass(context, current.subject, timeoutMs);
            schedule(context, current.hideEvent);
            return;
        }

        NotificationHelper.cancel(context);
        Event next = findNextEvent(now.plusSeconds(1));
        if (next != null) {
            schedule(context, next);
        } else {
            saveNextEventDebug(context, "없음");
        }
    }

    public static void scheduleNext(Context context) {
        if (!isEnabled(context)) return;
        Event next = findNextEvent(ZonedDateTime.now(SCHOOL_ZONE).plusSeconds(1));
        if (next != null) schedule(context, next);
    }

    private static void schedule(Context context, Event event) {
        AlarmManager am = context.getSystemService(AlarmManager.class);
        PendingIntent pi = pendingIntent(context, PendingIntent.FLAG_UPDATE_CURRENT);
        long at = event.when.toInstant().toEpochMilli();

        String action = event.show ? "표시" : "제거";
        saveNextEventDebug(context,
                DEBUG_TIME.format(event.when) + " · " + action + " · " + event.subject);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    // 정확도 우선. Doze/화면 꺼짐 상태에서도 해당 시각에 깨워서 처리한다.
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                } else {
                    // 사용자가 정확한 알람 권한을 아직 허용하지 않은 경우의 안전한 fallback.
                    // UI에서는 정확한 알람 권한을 필수로 안내하므로 실사용은 위 분기를 목표로 한다.
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                }
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    public static void cancelAll(Context context) {
        AlarmManager am = context.getSystemService(AlarmManager.class);
        PendingIntent pi = pendingIntentForCancel(context);
        if (pi != null) am.cancel(pi);
        NotificationHelper.cancel(context);
        saveNextEventDebug(context, "꺼짐");
    }

    private static PendingIntent pendingIntent(Context context, int creationFlag) {
        Intent intent = new Intent(context, AlarmReceiver.class)
                .setAction(ACTION_EVENT);

        return PendingIntent.getBroadcast(
                context,
                REQUEST_NEXT_EVENT,
                intent,
                creationFlag | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static PendingIntent pendingIntentForCancel(Context context) {
        Intent intent = new Intent(context, AlarmReceiver.class).setAction(ACTION_EVENT);
        return PendingIntent.getBroadcast(
                context,
                REQUEST_NEXT_EVENT,
                intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static Event findNextEvent(ZonedDateTime after) {
        Event best = null;

        // 최대 8일만 보면 다음 평일 이벤트를 반드시 찾을 수 있다.
        for (int d = 0; d <= 8; d++) {
            LocalDate date = after.toLocalDate().plusDays(d);
            DayOfWeek day = date.getDayOfWeek();
            List<String> classes = ScheduleData.classesFor(day);
            if (classes.size() < 2) continue;

            for (int transition = 0; transition < classes.size() - 1; transition++) {
                String subject = classes.get(transition + 1);
                ZonedDateTime show = ZonedDateTime.of(
                        date,
                        ScheduleData.END_TIMES[transition].minusMinutes(5),
                        SCHOOL_ZONE
                );
                ZonedDateTime hide = ZonedDateTime.of(
                        date,
                        ScheduleData.START_TIMES[transition + 1],
                        SCHOOL_ZONE
                );

                if (show.isAfter(after)) {
                    Event e = new Event(show, true, subject);
                    if (best == null || e.when.isBefore(best.when)) best = e;
                }
                if (hide.isAfter(after)) {
                    Event e = new Event(hide, false, subject);
                    if (best == null || e.when.isBefore(best.when)) best = e;
                }
            }
        }
        return best;
    }

    private static CurrentWindow currentWindow(ZonedDateTime now) {
        List<String> classes = ScheduleData.classesFor(now.getDayOfWeek());
        if (classes.size() < 2) return null;

        LocalDate date = now.toLocalDate();
        for (int transition = 0; transition < classes.size() - 1; transition++) {
            ZonedDateTime show = ZonedDateTime.of(
                    date,
                    ScheduleData.END_TIMES[transition].minusMinutes(5),
                    SCHOOL_ZONE
            );
            ZonedDateTime hide = ZonedDateTime.of(
                    date,
                    ScheduleData.START_TIMES[transition + 1],
                    SCHOOL_ZONE
            );

            // show <= now < hide 인 동안에만 다음 교시를 유지한다.
            if (!now.isBefore(show) && now.isBefore(hide)) {
                String subject = classes.get(transition + 1);
                return new CurrentWindow(subject, new Event(hide, false, subject));
            }
        }
        return null;
    }

    public static void recordAlarmFired(Context context) {
        String value = DEBUG_TIME.format(ZonedDateTime.now(SCHOOL_ZONE));
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(PREF_LAST_FIRED, value).apply();
    }

    public static String schedulingDiagnostics(Context context) {
        String next = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(PREF_NEXT_EVENT, "아직 예약되지 않음");
        String last = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(PREF_LAST_FIRED, "아직 없음");
        return "예약 방식: " + (canSchedulePrecisely(context)
                ? "정확한 WAKEUP (Doze 허용)"
                : "정확한 알람 권한 필요")
                + "\n다음 예약: " + next
                + "\n마지막 예약 실행: " + last;
    }

    private static void saveNextEventDebug(Context context, String value) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(PREF_NEXT_EVENT, value).apply();
    }


    /**
     * 실제 AlarmManager 경로 검증용. 버튼을 누른 뒤 앱을 최근 앱에서 닫아도
     * 20초 후 Now Bar/Status Chip이 떠야 한다. 일반 시간표 예약과 별도 PendingIntent를 사용한다.
     */
    public static boolean scheduleWakeupTest(Context context) {
        AlarmManager am = context.getSystemService(AlarmManager.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
            return false;
        }

        Intent intent = new Intent(context, WakeupTestReceiver.class)
                .setAction("com.yongjae.nextclasschip.WAKEUP_TEST");
        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                4199,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        long at = System.currentTimeMillis() + 20_000L;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } else {
            am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
        }
        return true;
    }

    public static String nextWindowSummary() {
        ZonedDateTime now = ZonedDateTime.now(SCHOOL_ZONE);
        List<String> classes = ScheduleData.classesFor(now.getDayOfWeek());

        if (classes.size() >= 2) {
            for (int transition = 0; transition < classes.size() - 1; transition++) {
                LocalTime showTime = ScheduleData.END_TIMES[transition].minusMinutes(5);
                LocalTime hideTime = ScheduleData.START_TIMES[transition + 1];
                ZonedDateTime show = ZonedDateTime.of(now.toLocalDate(), showTime, SCHOOL_ZONE);
                ZonedDateTime hide = ZonedDateTime.of(now.toLocalDate(), hideTime, SCHOOL_ZONE);
                if (now.isBefore(hide)) {
                    String subject = classes.get(transition + 1);
                    if (!now.isBefore(show)) {
                        return "지금 표시 중 · 다음교시: " + subject + " · " + hideTime + "에 제거";
                    }
                    long mins = Math.max(0, Duration.between(now, show).toMinutes());
                    return "다음 표시 · " + showTime + " → " + hideTime + " · 다음교시: "
                            + subject + " (약 " + mins + "분 후)";
                }
            }
        }

        Event next = findNextEvent(now.plusSeconds(1));
        if (next != null && next.show) {
            return "다음 표시 · " + ScheduleData.dayName(next.when.getDayOfWeek()) + " "
                    + next.when.toLocalTime() + " · 다음교시: " + next.subject;
        }
        return "오늘 알림은 모두 끝났습니다.";
    }

    private static final class Event {
        final ZonedDateTime when;
        final boolean show;
        final String subject;

        Event(ZonedDateTime when, boolean show, String subject) {
            this.when = when;
            this.show = show;
            this.subject = subject;
        }
    }

    private static final class CurrentWindow {
        final String subject;
        final Event hideEvent;

        CurrentWindow(String subject, Event hideEvent) {
            this.subject = subject;
            this.hideEvent = hideEvent;
        }
    }
}
