NextClassChip v1.3 chip diagnostic
- Android 16.1 / One UI 8.5 Live Update 진단 버전
- 새 Notification Channel (IMPORTANCE_DEFAULT, 무음/무진동)
- ProgressStyle 적용
- 30초 테스트 시 승격 요청/자격/허용/실제 시스템 승격 값을 앱 화면에 표시
- applicationId를 v13으로 변경하여 이전 테스트 APK와 서명 충돌 없이 별도 설치 가능
