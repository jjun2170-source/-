package com.yongjae.nextclasschip;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.service.notification.StatusBarNotification;

public final class NotificationHelper {
    private NotificationHelper() {}

    // v1.3에서 새 채널을 사용한다. 기존 LOW 채널 설정이 기기에 남아 있는 영향을 피하기 위함.
    public static final String CHANNEL_ID = "next_class_live_v13";
    public static final int NOTIFICATION_ID = 1001;
    public static final int TEST_NOTIFICATION_ID = 1002;

    public static void ensureChannel(Context context) {
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "다음 교시 · 실시간",
                NotificationManager.IMPORTANCE_DEFAULT
        );
        channel.setDescription("다음 수업이 가까워졌을 때 Live Update/Status Chip으로 표시합니다.");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setShowBadge(false);
        nm.createNotificationChannel(channel);
    }

    public static void showNextClass(Context context, String subject) {
        show(context, subject, NOTIFICATION_ID);
    }

    public static void showTest(Context context, String subject) {
        show(context, subject, TEST_NOTIFICATION_ID);
    }

    private static void show(Context context, String subject, int id) {
        if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        ensureChannel(context);

        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                0,
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_school)
                .setContentTitle("다음교시: " + subject)
                .setContentText("다음 수업이 곧 시작합니다.")
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_STATUS)
                .setShowWhen(false)
                .setColorized(false)
                .setShortCriticalText(chipText(subject));

        // Samsung/OEM이 일반 템플릿보다 진행형 Live Update를 더 엄격하게 취급할 가능성에 대비.
        if (Build.VERSION.SDK_INT >= 36) {
            builder.setStyle(new Notification.ProgressStyle()
                    .setProgressIndeterminate(true));
        }

        if (Build.VERSION.SDK_INT_FULL >= Build.VERSION_CODES_FULL.BAKLAVA_1) {
            builder.setRequestPromotedOngoing(true);
        }

        Notification notification = builder.build();
        context.getSystemService(NotificationManager.class).notify(id, notification);
    }

    public static String chipText(String subject) {
        String full = "다음교시:" + subject;
        int count = full.codePointCount(0, full.length());
        return count <= 7 ? full : subject;
    }

    public static String promotionDiagnostics(Context context, int id) {
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        boolean canPost = Build.VERSION.SDK_INT >= 36 && nm.canPostPromotedNotifications();
        StatusBarNotification target = null;
        for (StatusBarNotification sbn : nm.getActiveNotifications()) {
            if (sbn.getId() == id) {
                target = sbn;
                break;
            }
        }
        if (target == null) {
            return "진단: 게시된 테스트 알림을 찾지 못함";
        }

        Notification n = target.getNotification();
        boolean promotable = Build.VERSION.SDK_INT >= 36 && n.hasPromotableCharacteristics();
        boolean promoted = Build.VERSION.SDK_INT >= 36 &&
                (n.flags & Notification.FLAG_PROMOTED_ONGOING) != 0;
        boolean requested = Build.VERSION.SDK_INT_FULL >= Build.VERSION_CODES_FULL.BAKLAVA_1
                && n.isRequestPromotedOngoing();
        NotificationChannel channel = nm.getNotificationChannel(CHANNEL_ID);
        int importance = channel == null ? -1 : channel.getImportance();

        return "Live Update 진단\n" +
                "• 승격 요청: " + ox(requested) + "\n" +
                "• Android 자격 충족: " + ox(promotable) + "\n" +
                "• 앱 승격 허용: " + ox(canPost) + "\n" +
                "• 시스템 실제 승격: " + ox(promoted) + "\n" +
                "• 채널 중요도: " + importance + " (DEFAULT=3)";
    }

    private static String ox(boolean value) {
        return value ? "O" : "X";
    }

    public static void cancel(Context context) {
        context.getSystemService(NotificationManager.class).cancel(NOTIFICATION_ID);
    }

    public static void cancelTest(Context context) {
        context.getSystemService(NotificationManager.class).cancel(TEST_NOTIFICATION_ID);
    }
}
