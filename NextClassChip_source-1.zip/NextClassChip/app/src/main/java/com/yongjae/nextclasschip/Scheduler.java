package com.yongjae.nextclasschip;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

public final class Scheduler {
    private Scheduler() {}

    public static final String PREFS = "next_class_prefs";
    public static final String PREF_ENABLED = "enabled";
    public static final String ACTION_SHOW = "com.yongjae.nextclasschip.SHOW";
    public static final String ACTION_HIDE = "com.yongjae.nextclasschip.HIDE";
    private static final ZoneId SCHOOL_ZONE = ZoneId.of("Asia/Seoul");

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(PREF_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(PREF_ENABLED, enabled).apply();
    }

    public static void scheduleAll(Context context) {
        if (!isEnabled(context)) return;

        for (DayOfWeek day : List.of(
                DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
                DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)) {
            List<String> classes = ScheduleData.classesFor(day);
            for (int transition = 0; transition < classes.size() - 1; transition++) {
                scheduleEvent(context, day, transition, true);
                scheduleEvent(context, day, transition, false);
            }
        }
    }

    public static void scheduleEvent(Context context, DayOfWeek day, int transition, boolean show) {
        List<String> classes = ScheduleData.classesFor(day);
        if (transition < 0 || transition >= classes.size() - 1) return;

        LocalTime eventTime;
        String subject = classes.get(transition + 1);
        if (show) {
            eventTime = ScheduleData.END_TIMES[transition].minusMinutes(5);
        } else {
            eventTime = ScheduleData.START_TIMES[transition + 1];
        }

        long triggerAtMillis = nextOccurrenceMillis(day, eventTime);
        PendingIntent pi = pendingIntent(context, day, transition, show, subject, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = context.getSystemService(AlarmManager.class);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            } else {
                // 권한이 없으면 동작 자체는 유지하되 약간 늦어질 수 있는 fallback.
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            }
        } catch (SecurityException e) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        }
    }

    public static void cancelAll(Context context) {
        AlarmManager alarmManager = context.getSystemService(AlarmManager.class);
        for (DayOfWeek day : List.of(
                DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
                DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)) {
            List<String> classes = ScheduleData.classesFor(day);
            for (int transition = 0; transition < classes.size() - 1; transition++) {
                PendingIntent showPi = pendingIntent(context, day, transition, true,
                        classes.get(transition + 1), PendingIntent.FLAG_NO_CREATE);
                PendingIntent hidePi = pendingIntent(context, day, transition, false,
                        classes.get(transition + 1), PendingIntent.FLAG_NO_CREATE);
                if (showPi != null) alarmManager.cancel(showPi);
                if (hidePi != null) alarmManager.cancel(hidePi);
            }
        }
        NotificationHelper.cancel(context);
    }

    private static PendingIntent pendingIntent(
            Context context,
            DayOfWeek day,
            int transition,
            boolean show,
            String subject,
            int creationFlag
    ) {
        String action = show ? ACTION_SHOW : ACTION_HIDE;
        Intent intent = new Intent(context, AlarmReceiver.class)
                .setAction(action + ":" + day.getValue() + ":" + transition)
                .putExtra("show", show)
                .putExtra("day", day.getValue())
                .putExtra("transition", transition)
                .putExtra("subject", subject);

        int requestCode = day.getValue() * 100 + transition * 2 + (show ? 0 : 1);
        return PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                creationFlag | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static long nextOccurrenceMillis(DayOfWeek day, LocalTime time) {
        ZonedDateTime now = ZonedDateTime.now(SCHOOL_ZONE);
        LocalDate date = now.toLocalDate().with(TemporalAdjusters.nextOrSame(day));
        ZonedDateTime candidate = ZonedDateTime.of(LocalDateTime.of(date, time), SCHOOL_ZONE);
        if (!candidate.isAfter(now.plusSeconds(2))) {
            candidate = candidate.plusWeeks(1);
        }
        return candidate.toInstant().toEpochMilli();
    }

    public static String nextWindowSummary() {
        ZonedDateTime now = ZonedDateTime.now(SCHOOL_ZONE);
        DayOfWeek today = now.getDayOfWeek();
        List<String> classes = ScheduleData.classesFor(today);
        if (classes.size() < 2) return "오늘은 시간표 알림이 없습니다.";

        for (int transition = 0; transition < classes.size() - 1; transition++) {
            LocalTime showTime = ScheduleData.END_TIMES[transition].minusMinutes(5);
            LocalTime hideTime = ScheduleData.START_TIMES[transition + 1];
            ZonedDateTime show = ZonedDateTime.of(now.toLocalDate(), showTime, SCHOOL_ZONE);
            ZonedDateTime hide = ZonedDateTime.of(now.toLocalDate(), hideTime, SCHOOL_ZONE);
            if (now.isBefore(hide)) {
                String subject = classes.get(transition + 1);
                if (!now.isBefore(show)) {
                    return "지금 표시 구간 · 다음교시: " + subject + " · " + hideTime + "까지";
                }
                long mins = Math.max(0, Duration.between(now, show).toMinutes());
                return "다음 표시 · " + showTime + " · 다음교시: " + subject + " (약 " + mins + "분 후)";
            }
        }
        return "오늘 알림은 모두 끝났습니다.";
    }
}
