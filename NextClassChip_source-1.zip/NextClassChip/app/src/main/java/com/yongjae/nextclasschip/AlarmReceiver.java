package com.yongjae.nextclasschip;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.time.DayOfWeek;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        boolean show = intent.getBooleanExtra("show", false);
        int dayValue = intent.getIntExtra("day", 1);
        int transition = intent.getIntExtra("transition", 0);
        String subject = intent.getStringExtra("subject");

        if (Scheduler.isEnabled(context)) {
            if (show && subject != null) {
                NotificationHelper.showNextClass(context, subject);
            } else if (!show) {
                NotificationHelper.cancel(context);
            }
        }

        // 반복 알람을 쓰지 않고, 정확도를 위해 같은 이벤트의 다음 주 발생분을 다시 예약합니다.
        try {
            Scheduler.scheduleEvent(context, DayOfWeek.of(dayValue), transition, show);
        } catch (Exception ignored) {
        }
    }
}
