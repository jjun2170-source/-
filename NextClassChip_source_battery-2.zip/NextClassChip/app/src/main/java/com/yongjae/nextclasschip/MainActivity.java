package com.yongjae.nextclasschip;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.DayOfWeek;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_NOTIFICATIONS = 10;
    private TextView statusView;
    private TextView nextView;
    private Button enableButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NotificationHelper.ensureChannel(this);
        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        if (Scheduler.isEnabled(this)) {
            Scheduler.syncAndScheduleNext(this);
        }
    }

    private View buildUi() {
        int pad = dp(20);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = text("다음교시 바", 28, true);
        root.addView(title);

        TextView subtitle = text("3학년 5반 김용재 · 2026학년도 2학기", 16, false);
        subtitle.setPadding(0, dp(4), 0, dp(16));
        root.addView(subtitle);

        statusView = text("", 15, false);
        statusView.setPadding(dp(14), dp(12), dp(14), dp(12));
        statusView.setBackgroundColor(Color.rgb(242, 242, 242));
        root.addView(statusView, matchWrap());

        nextView = text("", 17, true);
        nextView.setPadding(0, dp(16), 0, dp(10));
        root.addView(nextView);

        Button notificationButton = button("1. 알림 권한 허용");
        notificationButton.setOnClickListener(v -> requestNotificationPermission());
        root.addView(notificationButton, matchWrap());

        Button exactButton = button("2. 정확한 시간 알림 허용");
        exactButton.setOnClickListener(v -> openExactAlarmSettings());
        root.addView(exactButton, matchWrap());

        Button promotedButton = button("3. 실시간 알림(Status Chip) 허용");
        promotedButton.setOnClickListener(v -> openPromotedSettings());
        root.addView(promotedButton, matchWrap());

        Button testButton = button("상태바 30초 테스트");
        testButton.setOnClickListener(v -> runChipTest());
        root.addView(testButton, matchWrap());

        enableButton = button("시간표 알림 켜기");
        enableButton.setOnClickListener(v -> toggleEnabled());
        root.addView(enableButton, matchWrap());

        TextView rules = text(
                "표시 규칙\n" +
                "• 각 수업 종료 5분 전부터 다음 수업 시작 직전까지 표시\n" +
                "• 5교시→6교시는 12:45~14:00 동안 표시\n" +
                "• 그날 마지막 수업 뒤에는 표시하지 않음\n" +
                "• 상태바는 가능한 경우 ‘다음교시:과목’, 길면 과목명만 표시\n" +
                "• 토·일에는 표시하지 않음",
                15,
                false
        );
        rules.setPadding(0, dp(20), 0, dp(12));
        root.addView(rules);

        TextView timetable = text(buildTimetableText(), 15, false);
        root.addView(timetable);

        return scroll;
    }

    private String buildTimetableText() {
        StringBuilder sb = new StringBuilder("내장 시간표\n");
        for (DayOfWeek day : List.of(
                DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
                DayOfWeek.THURSDAY, DayOfWeek.FRIDAY)) {
            sb.append(ScheduleData.dayName(day)).append("  ")
                    .append(String.join(" → ", ScheduleData.classesFor(day)))
                    .append("\n");
        }
        return sb.toString();
    }

    private void refreshStatus() {
        boolean notificationGranted = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
        AlarmManager am = getSystemService(AlarmManager.class);
        boolean exact = am.canScheduleExactAlarms();
        NotificationManager nm = getSystemService(NotificationManager.class);
        boolean promoted = Build.VERSION.SDK_INT >= 36 && nm.canPostPromotedNotifications();
        boolean full361 = Build.VERSION.SDK_INT_FULL >= Build.VERSION_CODES_FULL.BAKLAVA_1;

        String status = "Android SDK: " + Build.VERSION.SDK_INT_FULL +
                (full361 ? " (36.1 이상)" : " (36.1 미만)") +
                "\n알림 권한: " + yesNo(notificationGranted) +
                "\n정확한 알람: " + yesNo(exact) +
                "\n실시간 알림 허용: " + yesNo(promoted) +
                "\n시간표 알림: " + (Scheduler.isEnabled(this) ? "켜짐" : "꺼짐");

        statusView.setText(status);
        nextView.setText(Scheduler.nextWindowSummary());
        enableButton.setText(Scheduler.isEnabled(this) ? "시간표 알림 끄기" : "시간표 알림 켜기");
    }

    private void requestNotificationPermission() {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            toast("이미 알림 권한이 허용되어 있습니다.");
            return;
        }
        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
    }

    private void openExactAlarmSettings() {
        AlarmManager am = getSystemService(AlarmManager.class);
        if (am.canScheduleExactAlarms()) {
            toast("이미 정확한 시간 알림이 허용되어 있습니다.");
            return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            toast("이 기기에서 정확한 알람 설정 화면을 열 수 없습니다.");
        }
    }

    private void openPromotedSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_PROMOTION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            } else {
                toast("이 One UI 버전에서는 전용 실시간 알림 설정 화면이 노출되지 않습니다.");
            }
        } catch (Exception e) {
            toast("실시간 알림 설정 화면을 열 수 없습니다.");
        }
    }

    private void runChipTest() {
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            toast("먼저 알림 권한을 허용해 주세요.");
            requestNotificationPermission();
            return;
        }
        NotificationHelper.showTest(this, "물2");
        toast("30초 동안 ‘다음교시:물2’ Status Chip을 요청합니다.");
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            NotificationHelper.cancelTest(this);
            refreshStatus();
        }, 30_000);
    }

    private void toggleEnabled() {
        if (Scheduler.isEnabled(this)) {
            Scheduler.setEnabled(this, false);
            Scheduler.cancelAll(this);
            toast("시간표 알림을 껐습니다.");
        } else {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermission();
                toast("알림 권한을 허용한 뒤 다시 ‘켜기’를 눌러 주세요.");
                return;
            }
            Scheduler.setEnabled(this, true);
            Scheduler.syncAndScheduleNext(this);
            toast("시간표 알림을 켰습니다.");
        }
        refreshStatus();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshStatus();
    }

    private TextView text(String value, float sp, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sp);
        tv.setTextColor(Color.rgb(25, 25, 25));
        if (bold) tv.setTypeface(tv.getTypeface(), android.graphics.Typeface.BOLD);
        tv.setLineSpacing(0, 1.15f);
        return tv;
    }

    private Button button(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(15);
        button.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(8);
        button.setLayoutParams(lp);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private String yesNo(boolean value) {
        return value ? "허용됨" : "필요";
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
