package com.yongjae.nextclasschip;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public final class NotificationHelper {
    private NotificationHelper() {}

    public static final String CHANNEL_ID = "next_class_live";
    public static final int NOTIFICATION_ID = 1001;
    public static final int TEST_NOTIFICATION_ID = 1002;

    public static void ensureChannel(Context context) {
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "다음 교시",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("다음 수업이 가까워졌을 때 상태표시줄에 표시합니다.");
        channel.setSound(null, null);
        channel.enableVibration(false);
        channel.setShowBadge(false);
        nm.createNotificationChannel(channel);
    }

    public static void showNextClass(Context context, String subject) {
        show(context, subject, NOTIFICATION_ID);
    }

    public static void showTest(Context context, String subject) {
        show(context, subject, TEST_NOTIFICATION_ID);
    }

    private static void show(Context context, String subject, int id) {
        if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        ensureChannel(context);

        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                0,
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = new Notification.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_school)
                .setContentTitle("다음교시: " + subject)
                .setContentText("다음 수업이 곧 시작합니다.")
                .setContentIntent(contentIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_EVENT)
                .setShowWhen(false)
                .setShortCriticalText(chipText(subject));

        // Promoted ongoing 요청 API는 Android 16 minor release 1 (SDK 36.1)부터 제공됩니다.
        if (Build.VERSION.SDK_INT_FULL >= Build.VERSION_CODES_FULL.BAKLAVA_1) {
            builder.setRequestPromotedOngoing(true);
        }

        Notification notification = builder.build();
        context.getSystemService(NotificationManager.class).notify(id, notification);
    }

    public static String chipText(String subject) {
        // Android 공식 문서의 Status Chip 권장 최대 길이는 7자입니다.
        // 가능한 경우 '다음교시:'를 붙이고, 길어지면 과목명만 표시합니다.
        String full = "다음교시:" + subject;
        int count = full.codePointCount(0, full.length());
        return count <= 7 ? full : subject;
    }

    public static void cancel(Context context) {
        context.getSystemService(NotificationManager.class).cancel(NOTIFICATION_ID);
    }

    public static void cancelTest(Context context) {
        context.getSystemService(NotificationManager.class).cancel(TEST_NOTIFICATION_ID);
    }
}
