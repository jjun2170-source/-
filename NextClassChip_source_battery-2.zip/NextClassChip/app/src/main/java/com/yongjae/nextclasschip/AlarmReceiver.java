package com.yongjae.nextclasschip;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Scheduler.isEnabled(context)) return;

        boolean show = intent.getBooleanExtra("show", false);
        String subject = intent.getStringExtra("subject");

        if (show && subject != null && !subject.isEmpty()) {
            NotificationHelper.showNextClass(context, subject);
        } else {
            NotificationHelper.cancel(context);
        }

        // 한 이벤트가 끝난 뒤 다음 이벤트 1개만 예약.
        Scheduler.scheduleNext(context);
    }
}
