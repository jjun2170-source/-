package com.yongjae.nextclasschip;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ScheduleData {
    private ScheduleData() {}

    public static final LocalTime[] START_TIMES = {
            LocalTime.of(8, 0),
            LocalTime.of(9, 0),
            LocalTime.of(10, 0),
            LocalTime.of(11, 0),
            LocalTime.of(12, 0),
            LocalTime.of(14, 0),
            LocalTime.of(15, 0)
    };

    public static final LocalTime[] END_TIMES = {
            LocalTime.of(8, 50),
            LocalTime.of(9, 50),
            LocalTime.of(10, 50),
            LocalTime.of(11, 50),
            LocalTime.of(12, 50),
            LocalTime.of(14, 50),
            LocalTime.of(15, 50)
    };

    private static final EnumMap<DayOfWeek, List<String>> TIMETABLE = new EnumMap<>(DayOfWeek.class);

    static {
        TIMETABLE.put(DayOfWeek.MONDAY,
                List.of("지2", "물2", "영독작", "화작", "체육", "심리학"));
        TIMETABLE.put(DayOfWeek.TUESDAY,
                List.of("물2", "영독작", "화2", "지2", "화작", "심리학"));
        TIMETABLE.put(DayOfWeek.WEDNESDAY,
                List.of("수과탐", "사문탐", "미적분", "지2"));
        TIMETABLE.put(DayOfWeek.THURSDAY,
                List.of("화2", "심리학", "물2", "사문탐", "수과탐", "미적분", "체육"));
        TIMETABLE.put(DayOfWeek.FRIDAY,
                List.of("미적분", "사문탐", "화2", "영독작", "체육", "수과탐", "화작"));
    }

    public static List<String> classesFor(DayOfWeek day) {
        return TIMETABLE.getOrDefault(day, Collections.emptyList());
    }

    public static Map<DayOfWeek, List<String>> timetable() {
        return Collections.unmodifiableMap(TIMETABLE);
    }

    public static String dayName(DayOfWeek day) {
        return switch (day) {
            case MONDAY -> "월";
            case TUESDAY -> "화";
            case WEDNESDAY -> "수";
            case THURSDAY -> "목";
            case FRIDAY -> "금";
            case SATURDAY -> "토";
            case SUNDAY -> "일";
        };
    }
}
