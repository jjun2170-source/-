from datetime import time, timedelta, datetime

schedule = {
    '월': ['지2','물2','영독작','화작','체육','심리학'],
    '화': ['물2','영독작','화2','지2','화작','심리학'],
    '수': ['수과탐','사문탐','미적분','지2'],
    '목': ['화2','심리학','물2','사문탐','수과탐','미적분','체육'],
    '금': ['미적분','사문탐','화2','영독작','체육','수과탐','화작'],
}
starts = [time(8),time(9),time(10),time(11),time(12),time(14),time(15)]
ends   = [time(8,50),time(9,50),time(10,50),time(11,50),time(12,50),time(14,50),time(15,50)]

for day, classes in schedule.items():
    print(day, ' '.join(classes))
    for i in range(len(classes)-1):
        e = datetime.combine(datetime.today(), ends[i]) - timedelta(minutes=5)
        print(f'  {e:%H:%M}-{starts[i+1].strftime("%H:%M")}  다음교시:{classes[i+1]}')
